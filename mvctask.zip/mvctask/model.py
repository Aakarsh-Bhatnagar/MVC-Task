from pymongo import MongoClient
import pprint

try:
    conn= MongoClient()
    print('connected successfuly')
except:
    print('could not connect to mongodb')
    
db= conn['mvc-database']
employees= db.employees
class ModelClass:
    def insert(self, username, address):
        employee={
            'username': username,
            'address': address
        }
        employees.insert_one(employee)
        print('employee added successfuly')


    def delete(self,username):
        employees.delete_one({"username":username}) 


    def check(self,username):
        results= employees.count_documents({
            'username': username
        })
        if(results>0):
            return 1
        else:
            return 0
    

    def show_db(self):
        print('DATABASE:')
        employess= employees.find()
        for emp in employess:
            pprint.pprint(emp)

    def update(self,username,updatedusername,updatedaddress):
        employees.update_one( 
        {"username":username}, 
        { 
                "$set":{ 
                        "username":updatedusername,
                        "address":updatedaddress
                        }
                  
                } 
        )  