from model import ModelClass
modelobject=ModelClass()
class controller:

    def insert(self,username,address):
        flag=modelobject.check(username)
        if(flag==0):
            modelobject.insert(username,address)
        else:
            print('username already exist')
        modelobject.show_db()

    def delete(self,username):
        flag=modelobject.check(username)
        if(flag==1):
            modelobject.delete(username)
            print('user with username',username,'is deleted' )
        else:
            print('username doesnt exist')
        modelobject.show_db()

    def update(self,username,updatedusername,updatedaddress):
        flag=modelobject.check(username)
        if(flag==1):
            flag1=modelobject.check(updatedusername)
            if(flag1==0):
                modelobject.update(username,updatedusername,updatedaddress)
            else:
                print('username already exists please choose a different updated username')
           
        else:
            print('username doesnt exist')
        modelobject.show_db()
        