from flask import Flask
from flask import request
import json
from controller import controller
controllerobject=controller()
app=Flask(__name__)
@app.route('/insert', methods=['POST'])
def insert():
    data=request.get_json()
    username=data['username']
    address=data['address']
    controllerobject.insert(username,address)
    return "Insert Route Called"

@app.route('/delete', methods=['POST'])
def delete():
    data=request.get_json()
    username=data['username']
    controllerobject.delete(username)
    return "Delete route called"

@app.route('/update',methods=['POST'])
def update():
    data=request.get_json()
    username=data['username']
    updatedusername=data['updatedusername']
    updatedaddress=data['updatedaddress']
    controllerobject.update(username,updatedusername,updatedaddress)
    return "update route called"


if(__name__=="__main__"):
    app.run()
